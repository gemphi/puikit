import React from 'react';
import { Button, DataTable, ItemCard, Page, Rows, SpriteImage, Stack, Tag, Text, Title } from '@pui/components';
import { useStore } from '@pui/store';
import { D, rideSprite, seriesOf, t, worldImage, worldOf, rideKind } from '../../lib/data';
import { phieggStore } from '../../state/phieggStore';
import { Tile } from '../../components/Phiegg/Tile';
import { PageSections } from '../../components/Phiegg/PageSections';
import type { RideKind } from '../../types/phiegg';

const L = D.landing as unknown as {
  hero: { kicker: string; title: string; body: string; primary: string; secondary: string };
  pillars: { id: string; title: string; body: string }[];
  compare: { columns: string[]; rows: { label: string; a: string; b: string }[] };
  cta: { title: string; body: string; primary: string; secondary: string };
  featured?: { worldIds: string[]; seriesIds: string[] };
};
const KINDS: RideKind[] = ['car', 'cab', 'van', 'jetski', 'saucer', 'fun'];

/** The public home page: what Phiegg is, the worlds to visit, the rides, the stories, and the way in. Open to everyone. */
export const WelcomePage: React.FC = () => {
  const s = useStore(phieggStore);
  const worlds = (L.featured?.worldIds ?? []).map(worldOf).filter((w): w is NonNullable<typeof w> => !!w);
  const stories = (L.featured?.seriesIds ?? []).map(seriesOf).filter((x): x is NonNullable<typeof x> => !!x);
  const rides = KINDS.map((k) => D.ride.list.find((r) => r.kind === k)).filter((r): r is NonNullable<typeof r> => !!r);
  return (
    <Page>
      <Stack direction="column" gap={6}>
        <Tile image={worldImage(worlds[0])} tone="accent" ratio="21/8" big grid title={L.hero.title} sub={L.hero.body} depth={{ worldId: worlds[0]?.id, clubId: worlds[0]?.clubId }}
          badges={<Tag round size="sm">{L.hero.kicker}</Tag>} />
        <Stack direction="row" gap={2} wrap>
          <Button variant="primary" onClick={() => s.go('feed', { feedKind: 'all' })}>{L.hero.primary}</Button>
          <Button variant="outline" onClick={() => s.openSignIn()}>{t('hdSignIn')}</Button>
          <Button variant="ghost" onClick={() => s.go('phipad')}>{L.hero.secondary}</Button>
        </Stack>
        <PageSections id="welcome" sections={[
          { id: 'pillars', title: t('wlWhat'), content: (
            <Rows cols={4} colsSm={2} minItemWidth="13rem">{L.pillars.map((p) => <ItemCard key={p.id} depth={1} variant="flat" title={p.title}>{p.body}</ItemCard>)}</Rows>) },
          { id: 'worlds', title: t('wlWorlds'), hint: t('wlWorldsHint'), expandable: true, content: (
            <Rows cols={3} colsSm={1} minItemWidth="16rem">{worlds.map((w) => (
              <Tile key={w.id} image={worldImage(w)} tone={w.tone} ratio="16/9" grid title={w.name} sub={w.description} depth={{ worldId: w.id, clubId: w.clubId }} onClick={() => s.go('world', { worldId: w.id })} />))}</Rows>) },
          { id: 'rides', title: t('rdTitle'), hint: t('rdSub'), content: (
            <Rows cols={6} colsSm={2} minItemWidth="9rem">{rides.map((r) => (
              <ItemCard key={r.id} depth={1} variant="flat" layout="vertical" tint={r.hex} onClick={() => s.go('rides')} media={<SpriteImage sprite={rideSprite(r)} alt={r.name} ratio="16 / 10" radius="lg" />} title={rideKind(r.kind)} meta={r.name} />))}</Rows>) },
          { id: 'stories', title: t('wlStories'), hint: t('wlStoriesHint'), content: (
            <Rows cols={3} colsSm={1} minItemWidth="16rem">{stories.map((x) => (
              <ItemCard key={x.id} depth={1} variant="flat" onClick={() => s.openSeries(x.id)} title={x.title} meta={[x.genre, worldOf(x.worldId)?.name].filter(Boolean).join(' · ')}>
                <Stack direction="column" gap={1}><Text size="sm">{x.synopsis}</Text>{x.after && <Tag minimal round size="sm">{t('wsAfter', { work: x.after })}</Tag>}</Stack>
              </ItemCard>))}</Rows>) },
          { id: 'compare', title: t('wlCompare'), content: (
            <DataTable rows={L.compare.rows} getKey={(r) => r.label} columns={[{ id: 'label', header: '', cell: (r) => <Text as="span" size="sm" weight="semibold">{r.label}</Text> }, { id: 'a', header: L.compare.columns[0], cell: (r) => r.a }, { id: 'b', header: L.compare.columns[1], cell: (r) => r.b }]} />) },
        ]} />
        <Stack direction="column" gap={2} align="start">
          <Title level={2} size="xl">{L.cta.title}</Title><Text intent="secondary">{L.cta.body}</Text>
          <Stack direction="row" gap={2} wrap><Button variant="primary" onClick={() => s.go('phipad')}>{L.cta.primary}</Button><Button variant="outline" onClick={() => s.go('join')}>{L.cta.secondary}</Button></Stack>
        </Stack>
      </Stack>
    </Page>
  );
};
