import React from 'react';
import { Box, Spinner, Text, Title } from '@pui/components';
import { appMeta, loadApp, type AppData } from './data';
import { PhiShell } from './PhiShell';
import { Block, type GridItem } from './blocks';
import { YouView, SettingsView, ItemPanel } from './views';

const readHash = () => (window.location.hash.match(/^#\/?([\w-]+)/) || [])[1] || '';

/** A whole Phi app from its data file: sections from `nav`, pages from `views`, built-ins You + Settings. */
export const PhiApp: React.FC<{ appKey: string }> = ({ appKey }) => {
  const app = appMeta(appKey);
  const [data, setData] = React.useState<AppData | null>(null);
  const [err, setErr] = React.useState('');
  const [view, setView] = React.useState(readHash);
  const [open, setOpen] = React.useState<GridItem | null>(null);

  React.useEffect(() => { loadApp(appKey).then(setData, (e) => setErr(String(e.message || e))); }, [appKey]);
  React.useEffect(() => { const f = () => setView(readHash()); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  React.useEffect(() => { document.title = app ? app.name + ' · ' + app.tagline : appKey; }, [app, appKey]);

  const nav = data ? data.nav : [];
  const cur = view || (nav[0] && nav[0].id) || '';
  const go = (id: string) => { window.location.hash = '/' + id; setOpen(null); };
  const v = data && data.views[cur];

  let page: React.ReactNode;
  if (cur === '_you') page = <YouView />;
  else if (cur === '_settings') page = <SettingsView />;
  else if (err) page = <Text intent="secondary" maxWidth="60ch" marginTop={2}>{err}</Text>;
  else if (!data) page = <Spinner />;
  else if (!v) page = <Text intent="secondary" maxWidth="60ch" marginTop={2}>Nothing here yet.</Text>;
  else page = (
    <>
      {v.title ? <Box as="header"><Title level={1} size="2xl" lineHeight={1.1}>{v.title}</Title>{v.sub ? <Text intent="secondary" maxWidth="60ch" marginTop={2}>{v.sub}</Text> : null}</Box> : null}
      {v.blocks.map((b, i) => <Block key={cur + i} b={b} onOpen={setOpen} />)}
    </>
  );

  return (
    <PhiShell app={app} nav={nav} view={cur} onView={go} right={open ? <ItemPanel it={open} onClose={() => setOpen(null)} /> : null}>
      {page}
    </PhiShell>
  );
};
