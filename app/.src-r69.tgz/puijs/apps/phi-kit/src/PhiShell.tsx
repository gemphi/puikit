import { AppShell, type AppShellGroup, Button, Stack, TabList, Text } from '@pui/components';
import { usePuiTheme } from '@pui/providers';
import React from 'react';
import { Moon, Sun, User, Settings } from 'lucide-react';
import { APPS, appUrl, type AppMeta, type NavItem } from './data';
import { AppGlyph, NavIcon } from './icons';
import { LOOKS, useLook } from './looks';

export type ShellProps = {
  app: AppMeta; nav: NavItem[]; view: string; onView: (id: string) => void;
  right?: React.ReactNode; children: React.ReactNode;
};

/** The app's menu, as data, mapped to the shared shell: a nav item with `items` is a rail group with a sub-nav; one
 *  without is a leaf the rail navigates to. Apps are a secondary panel, never the primary rail. */
const toGroups = (nav: NavItem[]): AppShellGroup[] => nav.map((n) => ({
  id: n.id, label: n.label, icon: <NavIcon name={n.icon} size={20} />,
  items: (n.items && n.items.length ? n.items : [n]).map((it) => ({ id: it.id, label: it.label, icon: <NavIcon name={it.icon} size={18} /> })),
}));

/**
 * Every Phi app's shell is the puijs {@link AppShell}; this wrapper only feeds it the app's data — menu groups, the
 * app switcher, the built-in You/Settings, and the look switch. Nothing here is per-app logic.
 */
export const PhiShell: React.FC<ShellProps> = ({ app, nav, view, onView, right, children }) => {
  const apps = APPS.filter((a) => a.built || a.key === app.key).map((a) => ({
    id: a.key, name: a.name, tagline: a.key === app.key ? 'This app' : a.tagline,
    href: appUrl(a.key), current: a.key === app.key, color: a.color, glyph: <AppGlyph paths={a.icon} size={20} />,
  }));
  return (
    <AppShell
      brand={{ name: app.name, tagline: app.tagline, color: app.color, glyph: <AppGlyph paths={app.icon} size={22} /> }}
      groups={toGroups(nav)} view={view} onView={onView}
      apps={apps} appsLabel="Apps"
      foot={[{ id: '_you', label: 'You', icon: <User size={18} /> }, { id: '_settings', label: 'Settings', icon: <Settings size={18} /> }]}
      tools={<LookSwitch />} right={right}
    >
      {children}
    </AppShell>
  );
};

/** The look (Apple, SpaceX, Organic) and light or dark, one tap away in every app; Settings has the fine controls. */
const LookSwitch: React.FC = () => {
  const [look, setLook] = useLook();
  const { isDark, setTheme } = usePuiTheme();
  return (
    <Stack direction="column" gap={1} paddingX={2} paddingBottom={2}>
      <Stack direction="row" gap={1} align="center" justify="between">
        <Text as="span" size="xs" intent="muted">Look</Text>
        <Button variant="ghost" size="sm" onClick={() => setTheme(isDark ? 'light' : 'dark')} iconLeft={isDark ? Sun : Moon}>{isDark ? 'Light' : 'Dark'}</Button>
      </Stack>
      <TabList size="sm" variant="pills" aria-label="Look" activeId={look.id} onChange={setLook} items={LOOKS.map((l) => ({ id: l.id, label: l.label }))} />
    </Stack>
  );
};
