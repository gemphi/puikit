import React from 'react';
import { Box, Button, Frame, Image, Stack, Tag, Text, Title, ViewToolbar, type ViewMode } from '@pui/components';
import { appUrl, assetUrl, type Block } from '../data';
import s from '../kit.module.scss';

export type GridItem = { title: string; sub?: string; body?: string; action?: string; done?: string; app?: string; href?: string; cost?: number; meta?: string; image?: string };

/** One spacing scale for every card grid in every app, so the gaps between cards read the same everywhere. */
export const GRID_GAP = 4;
export const GRID_MIN = '16rem';
const TILE_W = '18rem';

/**
 * Card grid with the shared layout options: tile · list · grid, the same toolbar every list in the house uses. Card
 * opens the right-bar; the action toggles to its done label (or opens the linked app). Spacing comes from GRID_GAP,
 * one constant, so the gap between cards is identical across apps.
 */
export const Grid: React.FC<{ b: Block; onOpen: (it: GridItem) => void }> = ({ b, onOpen }) => {
  const [done, setDone] = React.useState<Record<number, boolean>>({});
  const [mode, setMode] = React.useState<ViewMode>((b.layout as ViewMode) || 'grid');
  const items: GridItem[] = b.items || [];

  const card = (it: GridItem, i: number, list: boolean) => (
    <Stack key={i} role="button" tabIndex={0} onClick={() => onOpen(it)} onKeyDown={(e) => e.key === 'Enter' && onOpen(it)}
      direction={list ? 'row' : 'column'} gap={list ? 3 : 2} align={list ? 'center' : 'stretch'} surface="card" className={s.cardBtn}
      width={mode === 'tile' ? TILE_W : undefined} flex={mode === 'tile' ? 'none' : undefined}>
      {it.image ? <Frame ratio={list ? '1/1' : '16/9'} rounded="md" width={list ? '5rem' : undefined} flex={list ? 'none' : undefined}><Image src={assetUrl(it.image)} alt="" fit="cover" fill loading="lazy" /></Frame> : null}
      <Stack direction="column" gap={list ? 1 : 2} flex={list ? '1' : undefined} minWidth="0">
        <Stack direction="row" gap={2} wrap align="center">{it.sub ? <Tag minimal round>{it.sub}</Tag> : null}</Stack>
        <Title level={3} size="md">{it.title}</Title>
        {it.body ? <Text as="p" size="sm" intent="secondary" flex={list ? undefined : '1'}>{it.body}</Text> : null}
        {it.meta ? <Text as="span" size="xs" intent="muted" mono>{it.meta}</Text> : null}
      </Stack>
      {it.action ? (
        it.app || it.href
          ? <Button variant="outline" size="sm" href={it.href || appUrl(it.app!)} onClick={(e: React.MouseEvent) => e.stopPropagation()}>{it.action}</Button>
          : <Button variant={done[i] ? 'ghost' : 'outline'} size="sm" onClick={(e) => { e.stopPropagation(); setDone((d) => ({ ...d, [i]: !d[i] })); }}>{done[i] ? it.done || 'Done' : it.action}</Button>
      ) : null}
    </Stack>
  );

  const body =
    mode === 'list' ? <Stack direction="column" gap={2}>{items.map((it, i) => card(it, i, true))}</Stack> :
    mode === 'tile' ? <Box scroll="x" paddingBottom={2}><Stack direction="row" gap={GRID_GAP} align="stretch">{items.map((it, i) => card(it, i, false))}</Stack></Box> :
    <Stack autoFill={GRID_MIN} gap={GRID_GAP}>{items.map((it, i) => card(it, i, false))}</Stack>;

  return (
    <Stack direction="column" gap={3}>
      <ViewToolbar mode={mode} onMode={setMode} count={items.length === 1 ? '1 item' : `${items.length} items`} />
      {body}
    </Stack>
  );
};
