import React from 'react';
import { Button, Input, Select, Stack, StepForm, type StepFormStep, TabList, Text, Textarea } from '@pui/components';
import { CheckCircle2 } from 'lucide-react';
import type { Block } from '../data';
import { apiPost, hasApi } from '../api';
import { NavIcon } from '../icons';

type FieldDef = { id: string; label: string; control?: string; options?: string[]; placeholder?: string; hint?: string; full?: boolean };
type StepDef = { id: string; label: string; icon?: string; title?: string; lede?: string; fields?: FieldDef[]; review?: boolean };

const Control: React.FC<{ f: FieldDef; value: string; onChange: (v: string) => void }> = ({ f, value, onChange }) => {
  switch (f.control) {
    case 'textarea': return <Textarea value={value} rows={3} placeholder={f.placeholder} onChange={(e) => onChange(e.target.value)} />;
    case 'select': return <Select value={value} onChange={(e) => onChange(e.target.value)} options={(f.options ?? []).map((o) => ({ value: o, label: o }))} />;
    case 'radio': return <TabList size="sm" variant="pills" activeId={value} onChange={(id) => onChange(String(id))} items={(f.options ?? []).map((o) => ({ id: o, label: o }))} />;
    case 'number': return <Input type="number" value={value} placeholder={f.placeholder} onChange={(e) => onChange(e.target.value)} />;
    default: return <Input value={value} placeholder={f.placeholder} onChange={(e) => onChange(e.target.value)} />;
  }
};

const trim = (s: string, n = 36) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

/**
 * A data-driven form block: the app declares its steps and fields (`{kind:'form', createKind, submitLabel, steps:[…]}`);
 * this renders them through the shared {@link StepForm}, so every application form in every app wears the same rail,
 * icons, active highlight and bordered field groups. On submit it writes a record of `createKind` to Phiora. Add a form
 * to an app's data, never a form component per app.
 */
export const Form: React.FC<{ b: Block }> = ({ b }) => {
  const defs: StepDef[] = b.steps ?? [];
  const allFields = defs.flatMap((s) => s.fields ?? []);
  const [vals, setVals] = React.useState<Record<string, string>>(() => Object.fromEntries(allFields.map((f) => [f.id, ''])));
  const [at, setAt] = React.useState(0);
  const [busy, setBusy] = React.useState(false);
  const [done, setDone] = React.useState(false);
  const set = (id: string) => (v: string) => setVals((x) => ({ ...x, [id]: v }));

  const submit = async () => {
    setBusy(true);
    if (hasApi && b.createKind) {
      const name = vals.name || vals.title || (b.title as string) || 'Untitled';
      await apiPost('/tree/item', { kind: b.createKind, fields: { ...vals, name } });
    }
    setBusy(false);
    setDone(true);
  };

  if (done) {
    return (
      <Stack direction="column" gap={3} surface="card" align="start">
        <Stack direction="row" gap={2} align="center"><NavIcon name="check" size={20} /><Text font="heading" size="lg">{b.doneTitle ?? 'Submitted'}</Text></Stack>
        <Text intent="secondary">{b.done ?? 'Your application was received and is under review.'}</Text>
        <Button variant="outline" onClick={() => { setVals(Object.fromEntries(allFields.map((f) => [f.id, '']))); setAt(0); setDone(false); }}>{b.againLabel ?? 'Submit another'}</Button>
      </Stack>
    );
  }

  const steps: StepFormStep[] = defs.map((s) => {
    const icon = s.icon ? <NavIcon name={s.icon} size={16} /> : undefined;
    if (s.review) {
      return {
        id: s.id, label: s.label, icon: icon ?? <CheckCircle2 size={16} />, title: s.title ?? s.label, lede: s.lede,
        content: (
          <Stack direction="column" gap={2} surface="card">
            {allFields.map((f) => (
              <Stack key={f.id} direction="row" justify="between" gap={3}>
                <Text size="sm" intent="muted">{f.label}</Text>
                <Text size="sm" truncate>{vals[f.id]?.trim() || '·'}</Text>
              </Stack>
            ))}
          </Stack>
        ),
      };
    }
    const chosen = (s.fields ?? []).map((f) => vals[f.id]?.trim()).filter(Boolean).join(' · ');
    return {
      id: s.id, label: s.label, icon, title: s.title ?? s.label, lede: s.lede, hint: chosen ? trim(chosen) : undefined,
      fields: (s.fields ?? []).map((f) => ({
        id: f.id, label: f.label, hint: f.hint, full: f.full ?? f.control === 'textarea',
        control: <Control f={f} value={vals[f.id] ?? ''} onChange={set(f.id)} />,
      })),
    };
  });

  return (
    <StepForm steps={steps} activeIndex={at} onStepChange={setAt} onSubmit={submit}
      submitLabel={b.submitLabel ?? 'Submit'} busy={busy} title={b.heading ?? b.title} sub={b.sub} fill={false} />
  );
};
