import { Box, Table as PuiTable } from '@pui/components';
import React from 'react';
import type { Block } from '../data';
import s from '../kit.module.scss';

export const Table: React.FC<{ b: Block }> = ({ b }) => (
  <Box surface="panel" padding={0} scroll="x">
    <PuiTable className={s.table} headers={b.cols || []} rows={b.rows || []} />
  </Box>
);
