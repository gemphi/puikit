import { mountPhiApp } from '@phi-kit/mount';

mountPhiApp('phient');
