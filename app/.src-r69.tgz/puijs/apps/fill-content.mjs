// Fill the data-driven apps' content from content/<key>.json banks: hero art, 12 dated news stories, 8 FAQs, fuller
// grids with art on every card, and a home feed (at a glance, explore, latest). Art is shared from phiegg's public
// folder as "phiegg:worlds/..." refs, so nothing is copied. Idempotent: everything added carries gen:true and is
// stripped and rebuilt on each run. Usage: cd puijs/apps && node fill-content.mjs [keys...]
import fs from 'node:fs';
import path from 'node:path';

const here = path.dirname(new URL(import.meta.url).pathname);
const W = path.join(here, 'phiegg/public/worlds');
const ART = [
  ...fs.readdirSync(W).filter((f) => f.endsWith('.png')).sort().map((f) => 'phiegg:worlds/' + f),
  ...fs.readdirSync(path.join(W, 'gen')).filter((f) => /\.(webp|png|jpg)$/.test(f)).sort().map((f) => 'phiegg:worlds/gen/' + f),
];
const hash = (s) => { let h = 2166136261; for (const c of s) h = Math.imul(h ^ c.charCodeAt(0), 16777619) >>> 0; return h; };
const art = (seed) => ART[hash(seed) % ART.length];
const fmt = (d) => d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' });
const day = (i) => fmt(new Date(Date.UTC(2026, 9, 12) - i * 4 * 864e5));
const strip = (arr) => (arr || []).filter((x) => !x.gen);
const SKIP_ART = new Set(['docs', 'api', 'cli', 'terminal']);

const KEYS = process.argv.slice(2).length ? process.argv.slice(2) : fs.readdirSync(path.join(here, 'content')).map((f) => f.replace(/\.json$/, ''));

for (const key of KEYS) {
  const file = path.join(here, key, 'public/data', key + '.json');
  const bank = JSON.parse(fs.readFileSync(path.join(here, 'content', key + '.json'), 'utf8'));
  const d = JSON.parse(fs.readFileSync(file, 'utf8'));
  const views = d.views;
  for (const v of Object.values(views)) { v.blocks = strip(v.blocks); for (const b of v.blocks) if (b.items) b.items = strip(b.items); }

  // News: originals first, then bank stories up to twelve; every story dated and illustrated.
  let stories = [];
  const newsBlock = views.news?.blocks.find((b) => b.kind === 'news');
  const have = new Set((newsBlock?.items || []).map((n) => n.title));
  const extra = bank.news.filter(([, t]) => !have.has(t)).map(([tag, title, body]) => ({ tag, title, body, gen: true }));
  if (newsBlock) {
    newsBlock.items = [...newsBlock.items, ...extra].slice(0, Math.max(12, newsBlock.items.length));
    newsBlock.items.forEach((n, i) => { if (n.gen) n.date = day(i); if (!n.image) { n.image = art(key + n.title); if (!n.gen) n.genImage = true; } });
    stories = newsBlock.items;
  } else {
    stories = extra.slice(0, 12).map((n, i) => ({ ...n, date: day(i), image: art(key + n.title) }));
  }

  // FAQ up to eight.
  const faq = Object.values(views).flatMap((v) => v.blocks).find((b) => b.kind === 'faq');
  if (faq) { const q = new Set(faq.items.map((x) => x.q)); faq.items.push(...bank.faq.filter((x) => !q.has(x.q)).slice(0, Math.max(0, 8 - faq.items.length)).map((x) => ({ ...x, gen: true }))); }

  // Grids: thin ones grow from the bank (once), every card outside the docs gets art.
  const cards = [...(bank.cards || [])];
  for (const [id, v] of Object.entries(views)) {
    if (id === 'home') continue;
    for (const b of v.blocks.filter((x) => x.kind === 'grid')) {
      const proto = b.items[0] || {};
      if (!SKIP_ART.has(id) && b.items.length < 6 && cards.length) {
        const titles = new Set(b.items.map((x) => x.title));
        while (b.items.length < 8 && cards.length) {
          const c = cards.shift();
          if (titles.has(c.title)) continue;
          b.items.push({ ...c, ...(proto.action ? { action: proto.action, done: proto.done } : {}), gen: true });
        }
      }
      if (!SKIP_ART.has(id)) for (const it of b.items) if (!it.image) { it.image = art(key + id + it.title); if (!it.gen) it.genImage = true; }
    }
  }

  // Home feed: hero art, then at a glance, explore every section, and the latest stories.
  const home = views.home;
  const hero = home.blocks.find((b) => b.kind === 'hero');
  if (hero && !hero.image) { hero.image = art(key + 'hero'); hero.genImage = true; }
  const leaves = d.nav.flatMap((n) => (n.items?.length ? n.items.map((i) => ({ ...i, group: n.label })) : [n])).filter((n) => n.id !== 'home' && views[n.id]);
  home.blocks.push(
    { kind: 'stats', title: 'At a glance', items: bank.stats, gen: true },
    { kind: 'grid', title: 'Explore', gen: true, items: leaves.map((n) => ({ title: views[n.id].title || n.label, sub: n.group || n.label, body: views[n.id].sub || '', action: 'Open', href: '#/' + n.id, image: art(key + 'nav' + n.id) })) },
    { kind: 'news', title: 'Latest', gen: true, items: stories.slice(0, 4) },
  );
  fs.writeFileSync(file, JSON.stringify(d, null, 2) + '\n');
  const all = JSON.stringify(d);
  console.log(key.padEnd(7), 'home', home.blocks.length, 'news', stories.length, 'faq', faq?.items.length ?? 0, 'images', (all.match(/"image":/g) || []).length);
}
